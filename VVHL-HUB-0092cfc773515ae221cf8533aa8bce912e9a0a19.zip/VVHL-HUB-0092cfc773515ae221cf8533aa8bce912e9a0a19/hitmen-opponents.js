(function(){
const TEAM='b0bcbdda-da9d-419d-8f61-b34937966d49',SEASON=55;
const S={games:[],opponents:[],snapshots:[],vods:[],selected:null,filter:'all',search:'',role:null,loading:false};
const E=id=>document.getElementById(id),DB=()=>window.VVHLBackend&&window.VVHLBackend.db,ST=()=>(window.VVHLBackend&&window.VVHLBackend.state)||{};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=v=>String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
const role=()=>String((ST().profile||{}).role||'').toLowerCase()==='admin'?'admin':((ST().memberships||[]).find(m=>m.team_id===TEAM&&m.active!==false)||{}).role||null;
const writable=()=>['admin','owner','gm','agm'].includes(String(S.role||'').toLowerCase());
const n=v=>v===''||v==null?null:Number(v);
const fmt=d=>new Date(d).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
function meetings(name){return S.games.filter(g=>g.opponent_name===name).sort((a,b)=>new Date(a.scheduled_at)-new Date(b.scheduled_at))}
function vodsFor(name){const ids=new Set(meetings(name).map(g=>g.id));return S.vods.filter(v=>ids.has(v.schedule_game_id)||norm(v.opponent_label)===norm(name))}
function h2h(name){let w=0,l=0,otl=0,gf=0,ga=0;meetings(name).filter(g=>g.status==='final'&&g.calgary_score!=null&&g.opponent_score!=null).forEach(g=>{gf+=g.calgary_score;ga+=g.opponent_score;if(g.calgary_score>g.opponent_score)w++;else if(g.overtime)otl++;else l++});return{w,l,otl,gf,ga,played:w+l+otl}}
function latestSnap(name){return S.snapshots.filter(x=>x.opponent_name===name).sort((a,b)=>new Date(b.as_of)-new Date(a.as_of))[0]||null}
function result(g){if(g.status!=='final'||g.calgary_score==null||g.opponent_score==null)return'—';return g.calgary_score>g.opponent_score?'W':g.overtime?'OTL':'L'}
function gameVodCount(g){return S.vods.filter(v=>v.schedule_game_id===g.id).length}
function updateKpis(){E('hoiGameCount').textContent=S.games.length;E('hoiOpponentCount').textContent=S.opponents.length;E('hoiRepeatCount').textContent=S.opponents.filter(o=>meetings(o.opponent_name).length>1).length;E('hoiFinalCount').textContent=S.games.filter(g=>g.status==='final').length;E('hoiVodCount').textContent=S.vods.length}
function renderOpponents(){
 const box=E('hoiOpponents');if(!box)return;
 let rows=S.opponents.filter(o=>!S.search||o.opponent_name.toLowerCase().includes(S.search));
 rows=rows.filter(o=>{const gs=meetings(o.opponent_name),played=gs.some(g=>g.status==='final'),up=gs.some(g=>g.status==='scheduled'&&new Date(g.scheduled_at)>=new Date());if(S.filter==='repeat')return gs.length>1;if(S.filter==='upcoming')return up;if(S.filter==='played')return played;return true});
 rows.sort((a,b)=>meetings(b.opponent_name).length-meetings(a.opponent_name).length||a.opponent_name.localeCompare(b.opponent_name));
 box.innerHTML=rows.map(o=>{const hs=h2h(o.opponent_name),m=meetings(o.opponent_name),vod=vodsFor(o.opponent_name).length;return '<button class="hoi-opp '+(S.selected===o.id?'active':'')+'" data-opp="'+o.id+'"><span><strong>'+esc(o.opponent_name)+'</strong><small>'+m.length+' meeting'+(m.length===1?'':'s')+' · '+vod+' VOD · '+(hs.played?hs.w+'-'+hs.l+(hs.otl?'-'+hs.otl:''):'not played')+'</small></span><b>'+m.length+'×</b></button>'}).join('')||'<div class="hoi-empty">No opponents match this filter.</div>';
 box.querySelectorAll('[data-opp]').forEach(b=>b.onclick=()=>selectOpponent(b.dataset.opp));
}
function renderSchedule(){
 const box=E('hoiSchedule');if(!box)return;const weeks=[...new Set(S.games.map(g=>g.week))].sort((a,b)=>a-b);
 box.innerHTML=weeks.map(w=>'<section class="hoi-week"><h3>Week '+w+'</h3>'+S.games.filter(g=>g.week===w).sort((a,b)=>new Date(a.scheduled_at)-new Date(b.scheduled_at)).map(g=>'<div class="hoi-game-row"><span class="time">'+esc(fmt(g.scheduled_at))+'</span><span class="opp">'+esc(g.opponent_name)+'</span><span class="score '+(g.status==='final'?'hoi-final':'hoi-upcoming')+'">'+(g.status==='final'?result(g)+' '+g.calgary_score+'-'+g.opponent_score:'Scheduled')+'</span><span class="vodc hoi-muted">'+gameVodCount(g)+' VOD</span><button data-game-opp="'+esc(g.opponent_name)+'">Intel</button></div>').join('')+'</section>').join('');
 box.querySelectorAll('[data-game-opp]').forEach(b=>b.onclick=()=>{const o=S.opponents.find(x=>x.opponent_name===b.dataset.gameOpp);if(o)selectOpponent(o.id)});
}
function fillProfile(o){E('hoiSummary').value=o.scouting_summary||'';E('hoiStrengths').value=o.strengths||'';E('hoiWeaknesses').value=o.weaknesses||'';E('hoiTendencies').value=o.tendencies||'';E('hoiDanger').value=o.danger_players||'';E('hoiLineupNotes').value=o.lineup_notes||'';E('hoiMatchupPlan').value=o.matchup_plan||'';E('hoiManagementNotes').value=o.management_notes||'';E('hoiConfidence').value=o.confidence||''}
function renderDetail(){
 const o=S.opponents.find(x=>x.id===S.selected);if(!o){E('hoiDetail').hidden=true;return}E('hoiDetail').hidden=false;E('hoiOpponentName').textContent=o.opponent_name;
 const ms=meetings(o.opponent_name),hs=h2h(o.opponent_name),vd=vodsFor(o.opponent_name),snap=latestSnap(o.opponent_name),next=ms.find(g=>g.status==='scheduled'&&new Date(g.scheduled_at)>=new Date());
 E('hoiOpponentMeta').textContent=ms.length+' scheduled meetings'+(next?' · next '+fmt(next.scheduled_at):'');
 E('hoiBattleLink').href='hitmen-battle-plan.html?opponent='+encodeURIComponent(o.opponent_name)+(next?'&date='+encodeURIComponent(next.scheduled_at.slice(0,10)):'');
 E('hoiRollup').innerHTML='<div><small>H2H</small><strong>'+hs.w+'-'+hs.l+(hs.otl?'-'+hs.otl:'')+'</strong></div><div><small>GF / GA</small><strong>'+hs.gf+' / '+hs.ga+'</strong></div><div><small>Meetings</small><strong>'+ms.length+'</strong></div><div><small>VODs</small><strong>'+vd.length+'</strong></div><div><small>Stats GP</small><strong>'+(snap&&snap.gp!=null?snap.gp:'—')+'</strong></div>';
 fillProfile(o);renderLatestStats(o.opponent_name);renderMeetings(o.opponent_name);renderVods(o.opponent_name);
 document.querySelectorAll('[data-write-only]').forEach(x=>x.disabled=!writable());
}
function stat(label,v,suffix=''){return '<div class="hoi-stat"><small>'+label+'</small><b>'+(v==null?'—':esc(v)+suffix)+'</b></div>'}
function renderLatestStats(name){
 const s=latestSnap(name),box=E('hoiLatestStats');if(!s){box.innerHTML='<div class="hoi-empty" style="grid-column:1/-1">No opponent stats snapshot yet. Start with league stats, then let VOD evidence refine the read.</div>'}else{
 box.innerHTML=stat('Record',(s.wins??0)+'-'+(s.losses??0)+(s.ot_losses!=null?'-'+s.ot_losses:''))+stat('GF / GA',(s.goals_for??'—')+' / '+(s.goals_against??'—'))+stat('Shots/G',s.shots_per_game)+stat('Shots Against/G',s.shots_against_per_game)+stat('FO%',s.faceoff_pct,'%')+stat('PP / PK',(s.power_play_pct??'—')+' / '+(s.penalty_kill_pct??'—'),'%');
 }
 const hist=S.snapshots.filter(x=>x.opponent_name===name).sort((a,b)=>new Date(b.as_of)-new Date(a.as_of)).slice(0,6);E('hoiSnapshotHistory').innerHTML=hist.map(x=>'<div class="hoi-snapshot"><b>'+esc(new Date(x.as_of).toLocaleDateString())+'</b> · '+esc((x.wins??0)+'-'+(x.losses??0)+(x.ot_losses!=null?'-'+x.ot_losses:''))+' · GF '+esc(x.goals_for??'—')+' / GA '+esc(x.goals_against??'—')+(x.notes?'<br>'+esc(x.notes):'')+'</div>').join('');
}
function renderMeetings(name){
 const box=E('hoiMeetings'),rows=meetings(name);
 box.innerHTML=rows.map((g,i)=>{
   const ts=g.team_stats||{},os=g.opponent_stats||{};
   return `<details class="hoi-meeting"><summary><span>${esc(fmt(g.scheduled_at))}</span><strong>Meeting ${i+1} of ${rows.length}</strong><b>${g.status==='final'?result(g)+' '+g.calgary_score+'-'+g.opponent_score:'UPCOMING'}</b></summary>
   <div class="hoi-game-edit" data-game="${g.id}">
   <label>Calgary score<input data-field="calgary_score" type="number" min="0" value="${esc(g.calgary_score??'')}"></label>
   <label>Opponent score<input data-field="opponent_score" type="number" min="0" value="${esc(g.opponent_score??'')}"></label>
   <label>Status<select data-field="status"><option value="scheduled" ${g.status==='scheduled'?'selected':''}>Scheduled</option><option value="final" ${g.status==='final'?'selected':''}>Final</option><option value="postponed" ${g.status==='postponed'?'selected':''}>Postponed</option><option value="cancelled" ${g.status==='cancelled'?'selected':''}>Cancelled</option></select></label>
   <label>OT loss?<select data-field="overtime"><option value="false" ${!g.overtime?'selected':''}>No</option><option value="true" ${g.overtime?'selected':''}>Yes</option></select></label>
   <div class="wide hoi-game-stats"><h4>Game Stats</h4><div class="hoi-game-stat-grid">
     <label>CGY Shots<input data-stat-side="team" data-stat="shots" type="number" min="0" value="${esc(ts.shots??'')}"></label>
     <label>OPP Shots<input data-stat-side="opponent" data-stat="shots" type="number" min="0" value="${esc(os.shots??'')}"></label>
     <label>CGY TOA<input data-stat-side="team" data-stat="toa" placeholder="6:42" value="${esc(ts.toa??'')}"></label>
     <label>OPP TOA<input data-stat-side="opponent" data-stat="toa" placeholder="5:18" value="${esc(os.toa??'')}"></label>
     <label>CGY Passing %<input data-stat-side="team" data-stat="passing_pct" type="number" step=".1" value="${esc(ts.passing_pct??'')}"></label>
     <label>OPP Passing %<input data-stat-side="opponent" data-stat="passing_pct" type="number" step=".1" value="${esc(os.passing_pct??'')}"></label>
     <label>CGY Faceoff %<input data-stat-side="team" data-stat="faceoff_pct" type="number" step=".1" value="${esc(ts.faceoff_pct??'')}"></label>
     <label>OPP Faceoff %<input data-stat-side="opponent" data-stat="faceoff_pct" type="number" step=".1" value="${esc(os.faceoff_pct??'')}"></label>
     <label>CGY Power Play<input data-stat-side="team" data-stat="power_play" placeholder="1/3" value="${esc(ts.power_play??'')}"></label>
     <label>OPP Power Play<input data-stat-side="opponent" data-stat="power_play" placeholder="0/2" value="${esc(os.power_play??'')}"></label>
     <label>CGY PIM<input data-stat-side="team" data-stat="pim" type="number" min="0" value="${esc(ts.pim??'')}"></label>
     <label>OPP PIM<input data-stat-side="opponent" data-stat="pim" type="number" min="0" value="${esc(os.pim??'')}"></label>
   </div></div>
   <label class="wide">What Calgary did well<textarea data-field="what_worked">${esc(g.what_worked||'')}</textarea></label>
   <label class="wide">What hurt Calgary / what failed<textarea data-field="what_failed">${esc(g.what_failed||'')}</textarea></label>
   <label class="wide">Opponent takeaways for the rematch<textarea data-field="opponent_takeaways">${esc(g.opponent_takeaways||'')}</textarea></label>
   <label class="wide">Matchup notes<textarea data-field="matchup_notes">${esc(g.matchup_notes||'')}</textarea></label>
   <button class="hm-save" data-save-game="${g.id}" ${writable()?'':'disabled'}>Save Game Record</button><span class="hm-save-note">${gameVodCount(g)} linked VOD${gameVodCount(g)===1?'':'s'}</span>
   </div></details>`;
 }).join('');
 box.querySelectorAll('[data-save-game]').forEach(b=>b.onclick=()=>saveGame(b.dataset.saveGame));
}
function renderVods(name){
 const box=E('hoiVods'),rows=vodsFor(name),games=meetings(name);if(!rows.length){box.innerHTML='<div class="hoi-empty">No matching VOD evidence yet. When you review this opponent in VOD Lab, it will appear here.</div>';return}
 box.innerHTML=rows.map(v=>'<div class="hoi-vod"><div><strong>'+esc(v.title||'Game review')+'</strong><small>'+esc(v.game_date?fmt(v.game_date):new Date(v.created_at).toLocaleDateString())+' · '+esc(v.worker_status||v.status||'review')+(v.tactical_report?' · tactical report ready':'')+'</small></div><div class="hoi-vod-actions"><select data-vod-game="'+v.id+'"><option value="">Attach to meeting…</option>'+games.map((g,i)=>'<option value="'+g.id+'" '+(v.schedule_game_id===g.id?'selected':'')+'>#'+(i+1)+' · '+esc(new Date(g.scheduled_at).toLocaleDateString())+'</option>').join('')+'</select><button data-attach-vod="'+v.id+'" '+(writable()?'':'disabled')+'>Attach</button><a href="vod-lab.html?review='+v.id+'">Open VOD</a></div></div>').join('');
 box.querySelectorAll('[data-attach-vod]').forEach(b=>b.onclick=()=>attachVod(b.dataset.attachVod));
}
async function selectOpponent(id){S.selected=id;renderOpponents();renderDetail();const o=S.opponents.find(x=>x.id===id);if(o)window.dispatchEvent(new CustomEvent('hitmen-opponent-selected',{detail:{id:o.id,name:o.opponent_name}}));setTimeout(()=>E('hoiDetail').scrollIntoView({behavior:'smooth',block:'start'}),50)}
async function saveOpponent(){if(!writable())return;const o=S.opponents.find(x=>x.id===S.selected);if(!o)return;E('hoiDetailStatus').textContent='Saving…';const payload={scouting_summary:E('hoiSummary').value.trim()||null,strengths:E('hoiStrengths').value.trim()||null,weaknesses:E('hoiWeaknesses').value.trim()||null,tendencies:E('hoiTendencies').value.trim()||null,danger_players:E('hoiDanger').value.trim()||null,lineup_notes:E('hoiLineupNotes').value.trim()||null,matchup_plan:E('hoiMatchupPlan').value.trim()||null,management_notes:E('hoiManagementNotes').value.trim()||null,confidence:n(E('hoiConfidence').value),updated_by:ST().user.id,updated_at:new Date().toISOString()};const r=await DB().from('hitmen_opponents').update(payload).eq('id',o.id);if(r.error){E('hoiDetailStatus').textContent=r.error.message;return}Object.assign(o,payload);E('hoiDetailStatus').textContent='Opponent report saved ✓'}
async function saveGame(id){if(!writable())return;const row=document.querySelector('[data-game="'+id+'"]'),g=S.games.find(x=>x.id===id);if(!row||!g)return;const v=k=>row.querySelector('[data-field="'+k+'"]').value;const statObj=side=>{const out={};row.querySelectorAll('[data-stat-side="'+side+'"]').forEach(el=>{const key=el.dataset.stat,val=el.value.trim();if(val!=='')out[key]=['shots','passing_pct','faceoff_pct','pim'].includes(key)?Number(val):val});return out};const payload={calgary_score:n(v('calgary_score')),opponent_score:n(v('opponent_score')),status:v('status'),overtime:v('overtime')==='true',team_stats:statObj('team'),opponent_stats:statObj('opponent'),what_worked:v('what_worked').trim()||null,what_failed:v('what_failed').trim()||null,opponent_takeaways:v('opponent_takeaways').trim()||null,matchup_notes:v('matchup_notes').trim()||null,updated_by:ST().user.id,updated_at:new Date().toISOString()};const r=await DB().from('hitmen_schedule_games').update(payload).eq('id',id);if(r.error)return alert(r.error.message);Object.assign(g,payload);renderSchedule();renderDetail()}
async function saveSnapshot(){if(!writable())return;const o=S.opponents.find(x=>x.id===S.selected);if(!o)return;const payload={team_id:TEAM,season:SEASON,opponent_name:o.opponent_name,gp:n(E('hsGp').value),wins:n(E('hsW').value),losses:n(E('hsL').value),ot_losses:n(E('hsOtl').value),goals_for:n(E('hsGf').value),goals_against:n(E('hsGa').value),shots_per_game:n(E('hsShots').value),shots_against_per_game:n(E('hsShotsA').value),faceoff_pct:n(E('hsFo').value),power_play_pct:n(E('hsPp').value),penalty_kill_pct:n(E('hsPk').value),source_url:E('hsSource').value.trim()||null,notes:E('hsNotes').value.trim()||null,created_by:ST().user.id};const r=await DB().from('hitmen_opponent_stat_snapshots').insert(payload).select('*').single();if(r.error)return alert(r.error.message);S.snapshots.push(r.data);['hsGp','hsW','hsL','hsOtl','hsGf','hsGa','hsShots','hsShotsA','hsFo','hsPp','hsPk','hsSource','hsNotes'].forEach(id=>E(id).value='');renderLatestStats(o.opponent_name)}
async function attachVod(id){if(!writable())return;const sel=document.querySelector('[data-vod-game="'+id+'"]'),gameId=sel&&sel.value||null;const r=await DB().from('vod_review_sessions').update({schedule_game_id:gameId,updated_at:new Date().toISOString()}).eq('id',id).eq('team_id',TEAM);if(r.error)return alert(r.error.message);const v=S.vods.find(x=>x.id===id);if(v)v.schedule_game_id=gameId;renderSchedule();renderDetail()}
function bind(){E('hoiSearch').oninput=e=>{S.search=e.target.value.trim().toLowerCase();renderOpponents()};document.querySelectorAll('[data-hoi-filter]').forEach(b=>b.onclick=()=>{S.filter=b.dataset.hoiFilter;document.querySelectorAll('[data-hoi-filter]').forEach(x=>x.classList.toggle('active',x===b));renderOpponents()});E('hoiSaveOpponent').onclick=saveOpponent;E('hoiSaveSnapshot').onclick=saveSnapshot}
async function load(){if(S.loading||!ST().user||!DB())return;S.loading=true;S.role=role();if(!S.role){S.loading=false;return}try{const q=await Promise.all([
DB().from('hitmen_schedule_games').select('*').eq('team_id',TEAM).eq('season',SEASON).order('scheduled_at'),
DB().from('hitmen_opponents').select('*').eq('team_id',TEAM).eq('season',SEASON).order('opponent_name'),
DB().from('hitmen_opponent_stat_snapshots').select('*').eq('team_id',TEAM).eq('season',SEASON).order('as_of',{ascending:false}),
DB().from('vod_review_sessions').select('id,title,opponent_label,game_date,status,worker_status,tactical_report,full_game_summary,schedule_game_id,created_at').eq('team_id',TEAM).order('created_at',{ascending:false})
]);const er=q.find(x=>x.error);if(er)throw er.error;S.games=q[0].data||[];S.opponents=q[1].data||[];S.snapshots=q[2].data||[];S.vods=q[3].data||[];updateKpis();renderOpponents();renderSchedule();if(S.selected)renderDetail();document.querySelectorAll('[data-write-only]').forEach(x=>x.disabled=!writable());E('hoiScheduleStatus').textContent=S.games.length+' games · '+S.opponents.length+' opponents loaded'}catch(e){console.error(e);E('hoiScheduleStatus').textContent=e.message||'Could not load opponent tracker'}finally{S.loading=false}}
window.addEventListener('vvhl-auth-change',load);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{bind();setTimeout(load,80)});else{bind();setTimeout(load,80)}
})();